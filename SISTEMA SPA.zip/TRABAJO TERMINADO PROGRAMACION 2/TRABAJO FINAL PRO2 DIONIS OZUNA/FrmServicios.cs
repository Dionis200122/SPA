﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text;


namespace TRABAJO_FINAL_PRO2_DIONIS_OZUNA
{
    public partial class FrmServicios : Form
    {
        private string cadena = "Data Source=DIONISOZUNA;Initial Catalog=spa;Integrated Security=True;TrustServerCertificate=True";
        private void LimpiarCampos()
        {
            txtServicioID.Text = "";
            txtNombre.Text = "";
            txtDuracion.Text = "";
            txtPrecio.Text = "";
            txtNombre.Focus();
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtDuracion.Text) ||
                string.IsNullOrWhiteSpace(txtPrecio.Text))
            {
                MessageBox.Show("Nombre, Duración y Precio son obligatorios.",
                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtDuracion.Text, out _) ||
                !decimal.TryParse(txtPrecio.Text, out _))
            {
                MessageBox.Show("Duración debe ser entero y Precio debe ser numérico.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void CargarServicios()
        {
            string sql = "SELECT ServicioID, Nombre, DuracionMinutos, Precio FROM Servicio";

            using (SqlConnection cn = new SqlConnection(cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter(sql, cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvServicios.DataSource = dt;
            }
        }

        public FrmServicios()
        {
            InitializeComponent();
        }

        private void FrmServicios_Load(object sender, EventArgs e)
        {
            txtServicioID.ReadOnly = true;   
            CargarServicios();              
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            CargarServicios();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
                return;

            string sql = @"INSERT INTO Servicio (Nombre, DuracionMinutos, Precio)
                   VALUES (@Nombre, @DuracionMinutos, @Precio)";

            using (SqlConnection cn = new SqlConnection(cadena))
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@DuracionMinutos", int.Parse(txtDuracion.Text));
                cmd.Parameters.AddWithValue("@Precio", decimal.Parse(txtPrecio.Text));

                cn.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Servicio guardado correctamente.", "Información",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            CargarServicios();
            LimpiarCampos();
        }

        private void dgvServicios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dgvServicios.Rows[e.RowIndex];

                txtServicioID.Text = fila.Cells["ServicioID"].Value.ToString();
                txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
                txtDuracion.Text = fila.Cells["DuracionMinutos"].Value.ToString();
                txtPrecio.Text = fila.Cells["Precio"].Value.ToString();
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtServicioID.Text))
            {
                MessageBox.Show("Seleccione un servicio de la lista.", "Advertencia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ValidarCampos())
                return;

            string sql = @"UPDATE Servicio
                   SET Nombre = @Nombre,
                       DuracionMinutos = @DuracionMinutos,
                       Precio = @Precio
                   WHERE ServicioID = @ServicioID";

            using (SqlConnection cn = new SqlConnection(cadena))
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@DuracionMinutos", int.Parse(txtDuracion.Text));
                cmd.Parameters.AddWithValue("@Precio", decimal.Parse(txtPrecio.Text));
                cmd.Parameters.AddWithValue("@ServicioID", int.Parse(txtServicioID.Text));

                cn.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Servicio actualizado correctamente.", "Información",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            CargarServicios();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtServicioID.Text))
            {
                MessageBox.Show("Seleccione un servicio para eliminar.", "Advertencia",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var r = MessageBox.Show("¿Seguro que desea eliminar este servicio?",
                "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (r != DialogResult.Yes)
                return;

            string sql = "DELETE FROM Servicio WHERE ServicioID = @ServicioID";

            using (SqlConnection cn = new SqlConnection(cadena))
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@ServicioID", int.Parse(txtServicioID.Text));
                cn.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Servicio eliminado correctamente.", "Información",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            CargarServicios();
            LimpiarCampos();
        }
        private string EscaparCsv(string valor)
        {
            if (valor == null)
                return "";
            valor = valor.Replace("\"", "\"\"");

            if (valor.Contains(";") || valor.Contains(",") || valor.Contains("\n") || valor.Contains("\""))
            {
                valor = "\"" + valor + "\"";
            }
            return valor;
        }

        private void btnExportarCsv_Click(object sender, EventArgs e)
        {
            if (dgvServicios.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos para exportar.", "Información",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "Archivo CSV (*.csv)|*.csv";
                sfd.FileName = "Servicios.csv";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        StringBuilder sb = new StringBuilder();

                        for (int i = 0; i < dgvServicios.Columns.Count; i++)
                        {
                            if (!dgvServicios.Columns[i].Visible)
                                continue;

                            sb.Append(EscaparCsv(dgvServicios.Columns[i].HeaderText));

                            if (i < dgvServicios.Columns.Count - 1)
                                sb.Append(";");
                        }
                        sb.AppendLine();

                        foreach (DataGridViewRow fila in dgvServicios.Rows)
                        {
                            if (fila.IsNewRow) 
                                continue;

                            for (int i = 0; i < dgvServicios.Columns.Count; i++)
                            {
                                if (!dgvServicios.Columns[i].Visible)
                                    continue;

                                var valor = fila.Cells[i].Value != null
                                    ? fila.Cells[i].Value.ToString()
                                    : "";

                                sb.Append(EscaparCsv(valor));

                                if (i < dgvServicios.Columns.Count - 1)
                                    sb.Append(";");
                            }
                            sb.AppendLine();
                        }

                        File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);

                        MessageBox.Show("Datos exportados correctamente.", "Información",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al exportar: " + ex.Message, "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
