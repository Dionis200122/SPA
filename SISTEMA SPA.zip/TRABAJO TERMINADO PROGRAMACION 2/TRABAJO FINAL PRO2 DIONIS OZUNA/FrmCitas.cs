﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TRABAJO_FINAL_PRO2_DIONIS_OZUNA
{
    public partial class FrmCitas : Form
    {
        private string cadena = "Data Source=DIONISOZUNA;Initial Catalog=spa;Integrated Security=True;TrustServerCertificate=True";

        public FrmCitas()
        {
            InitializeComponent();
        }
        private void LimpiarCampos()
        {
            txtCitaID.Clear();
            cmbPaciente.SelectedIndex = -1;
            cmbServicio.SelectedIndex = -1;
            cmbTerapeuta.SelectedIndex = -1;

            txtDuracion.Clear();
            txtDiasRestantes.Clear();
            txtHorasRestantes.Clear();

            cmbEstado.SelectedIndex = -1;

            dtpFecha.Value = DateTime.Now.Date;
            dtpHora.Value = DateTime.Now;
        }
        private bool ValidarCampos()
        {
            if (cmbPaciente.SelectedIndex == -1 ||
                cmbServicio.SelectedIndex == -1 ||
                cmbTerapeuta.SelectedIndex == -1 ||
                cmbEstado.SelectedIndex == -1)
            {
                MessageBox.Show("Paciente, Servicio, Terapeuta y Estado son obligatorios.",
                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtDuracion.Text))
            {
                MessageBox.Show("La duración debe estar definida (elige un servicio).",
                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
        private void CargarPacientes()
        {
            string sql = "SELECT PacienteID, Nombre FROM Paciente";

            using (SqlConnection cn = new SqlConnection(cadena))
            using (SqlDataAdapter da = new SqlDataAdapter(sql, cn))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);
                cmbPaciente.DataSource = dt;
                cmbPaciente.DisplayMember = "Nombre";
                cmbPaciente.ValueMember = "PacienteID";
                cmbPaciente.SelectedIndex = -1;
            }
        }
        private void CargarServicios()
        {
            string sql = "SELECT ServicioID, Nombre, DuracionMinutos FROM Servicio";

            using (SqlConnection cn = new SqlConnection(cadena))
            using (SqlDataAdapter da = new SqlDataAdapter(sql, cn))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);
                cmbServicio.DataSource = dt;
                cmbServicio.DisplayMember = "Nombre";
                cmbServicio.ValueMember = "ServicioID";
                cmbServicio.SelectedIndex = -1;
            }
        }
        private void CargarTerapeutas()
        {
            string sql = "SELECT TerapeutaID, Nombre FROM Terapeuta";

            using (SqlConnection cn = new SqlConnection(cadena))
            using (SqlDataAdapter da = new SqlDataAdapter(sql, cn))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);
                cmbTerapeuta.DataSource = dt;
                cmbTerapeuta.DisplayMember = "Nombre";
                cmbTerapeuta.ValueMember = "TerapeutaID";
                cmbTerapeuta.SelectedIndex = -1;
            }
        }
        private void CargarCitas()
        {
            string sql = @"
        SELECT c.CitaID,
               c.PacienteID,
               p.Nombre AS Paciente,
               c.ServicioID,
               s.Nombre AS Servicio,
               c.TerapeutaID,
               t.Nombre AS Terapeuta,
               c.Fecha,
               c.Hora,
               c.DuracionMinutos,
               c.DiasRestantes,
               c.HorasRestantes,
               c.Estado
        FROM Cita c
        JOIN Paciente  p ON c.PacienteID  = p.PacienteID
        JOIN Servicio  s ON c.ServicioID  = s.ServicioID
        JOIN Terapeuta t ON c.TerapeutaID = t.TerapeutaID";

            using (SqlConnection cn = new SqlConnection(cadena))
            using (SqlDataAdapter da = new SqlDataAdapter(sql, cn))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvCitas.DataSource = dt;
            }
        }
        private void CalcularTiempoRestante()
        {
            DateTime fecha = dtpFecha.Value.Date;
            TimeSpan hora = dtpHora.Value.TimeOfDay;
            DateTime fechaHoraCita = fecha + hora;

            TimeSpan diff = fechaHoraCita - DateTime.Now;

            int dias = diff.TotalDays > 0 ? (int)Math.Floor(diff.TotalDays) : 0;
            int horas = diff.TotalHours > 0 ? (int)Math.Floor(diff.TotalHours) : 0;

            txtDiasRestantes.Text = dias.ToString();
            txtHorasRestantes.Text = horas.ToString();
        }
        private void label4_Click(object sender, EventArgs e)
        {

        }
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvCitas.CurrentRow == null || dgvCitas.CurrentRow.IsNewRow)
            {
                MessageBox.Show("Seleccione una cita de la lista para eliminar.",
                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            int citaId = Convert.ToInt32(dgvCitas.CurrentRow.Cells["CitaID"].Value);
            var resp = MessageBox.Show("¿Seguro que desea eliminar la cita seleccionada?",
                "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resp != DialogResult.Yes)
                return;

            string sql = "DELETE FROM Cita WHERE CitaID = @CitaID";

            using (SqlConnection cn = new SqlConnection(cadena))
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@CitaID", citaId);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("Cita eliminada correctamente.", "Información",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            CargarCitas();
            LimpiarCampos();
        }
        private void FrmCitas_Load(object sender, EventArgs e)
        {
            CargarPacientes();
            CargarServicios();
            CargarTerapeutas();

            LimpiarCampos(); 
        }
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();


        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            CargarCitas();
        }
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtDuracion.Text) && cmbServicio.SelectedItem is DataRowView filaServ)
            {
                txtDuracion.Text = filaServ["DuracionMinutos"].ToString();
            }
            if (!ValidarCampos())
                return;
            CalcularTiempoRestante();

            DateTime fecha = dtpFecha.Value.Date;
            TimeSpan hora = dtpHora.Value.TimeOfDay;
            string sql = @"
        INSERT INTO Cita
            (PacienteID, ServicioID, TerapeutaID, Fecha, Hora,
             DuracionMinutos, DiasRestantes, HorasRestantes, Estado)
        VALUES
            (@PacienteID, @ServicioID, @TerapeutaID, @Fecha, @Hora,
             @DuracionMinutos, @DiasRestantes, @HorasRestantes, @Estado)";

            using (SqlConnection cn = new SqlConnection(cadena))
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@PacienteID", (int)cmbPaciente.SelectedValue);
                cmd.Parameters.AddWithValue("@ServicioID", (int)cmbServicio.SelectedValue);
                cmd.Parameters.AddWithValue("@TerapeutaID", (int)cmbTerapeuta.SelectedValue);
                cmd.Parameters.AddWithValue("@Fecha", fecha);
                cmd.Parameters.AddWithValue("@Hora", hora);
                cmd.Parameters.AddWithValue("@DuracionMinutos", int.Parse(txtDuracion.Text));
                cmd.Parameters.AddWithValue("@DiasRestantes", int.Parse(string.IsNullOrEmpty(txtDiasRestantes.Text) ? "0" : txtDiasRestantes.Text));
                cmd.Parameters.AddWithValue("@HorasRestantes", int.Parse(string.IsNullOrEmpty(txtHorasRestantes.Text) ? "0" : txtHorasRestantes.Text));
                cmd.Parameters.AddWithValue("@Estado", cmbEstado.Text);

                cn.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Cita guardada correctamente.", "Información",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            CargarCitas();
            LimpiarCampos();
        }
        private void txtDuracion_TextChanged(object sender, EventArgs e)
        {
            if (cmbServicio.SelectedItem == null)
                return;

            var fila = cmbServicio.SelectedItem as DataRowView;
            if (fila != null)
            {
                txtDuracion.Text = fila["DuracionMinutos"].ToString();
            }
        }

        private void dgvCitas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return; 

            DataGridViewRow fila = dgvCitas.Rows[e.RowIndex];

            txtCitaID.Text = fila.Cells["CitaID"].Value.ToString();
            cmbPaciente.SelectedValue = fila.Cells["PacienteID"].Value;
            cmbServicio.SelectedValue = fila.Cells["ServicioID"].Value;
            cmbTerapeuta.SelectedValue = fila.Cells["TerapeutaID"].Value;
            dtpFecha.Value = Convert.ToDateTime(fila.Cells["Fecha"].Value);

            TimeSpan hora;
            if (TimeSpan.TryParse(fila.Cells["Hora"].Value.ToString(), out hora))
            {
                dtpHora.Value = DateTime.Today + hora;
            }
            txtDuracion.Text = fila.Cells["DuracionMinutos"].Value.ToString();
            txtDiasRestantes.Text = fila.Cells["DiasRestantes"].Value?.ToString();
            txtHorasRestantes.Text = fila.Cells["HorasRestantes"].Value?.ToString();
            cmbEstado.Text = fila.Cells["Estado"].Value.ToString();
        }
        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
            txtCitaID.Clear();  
        }
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCitaID.Text))
            {
                MessageBox.Show("Seleccione una cita de la lista para actualizar.",
                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ValidarCampos())
                return;

            CalcularTiempoRestante();

            DateTime fecha = dtpFecha.Value.Date;
            TimeSpan hora = dtpHora.Value.TimeOfDay;

            string sql = @"
        UPDATE Cita
        SET PacienteID     = @PacienteID,
            ServicioID     = @ServicioID,
            TerapeutaID    = @TerapeutaID,
            Fecha          = @Fecha,
            Hora           = @Hora,
            DuracionMinutos= @DuracionMinutos,
            DiasRestantes  = @DiasRestantes,
            HorasRestantes = @HorasRestantes,
            Estado         = @Estado
        WHERE CitaID       = @CitaID";

            using (SqlConnection cn = new SqlConnection(cadena))
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@PacienteID", (int)cmbPaciente.SelectedValue);
                cmd.Parameters.AddWithValue("@ServicioID", (int)cmbServicio.SelectedValue);
                cmd.Parameters.AddWithValue("@TerapeutaID", (int)cmbTerapeuta.SelectedValue);
                cmd.Parameters.AddWithValue("@Fecha", fecha);
                cmd.Parameters.AddWithValue("@Hora", hora);
                cmd.Parameters.AddWithValue("@DuracionMinutos", int.Parse(txtDuracion.Text));
                cmd.Parameters.AddWithValue("@DiasRestantes", int.Parse(string.IsNullOrEmpty(txtDiasRestantes.Text) ? "0" : txtDiasRestantes.Text));
                cmd.Parameters.AddWithValue("@HorasRestantes", int.Parse(string.IsNullOrEmpty(txtHorasRestantes.Text) ? "0" : txtHorasRestantes.Text));
                cmd.Parameters.AddWithValue("@Estado", cmbEstado.Text);
                cmd.Parameters.AddWithValue("@CitaID", int.Parse(txtCitaID.Text));

                cn.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Cita actualizada correctamente.", "Información",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            CargarCitas();
            LimpiarCampos();
        }
        private string EscaparCsv(string valor)
        {
            if (valor == null)
                return "";
            valor = valor.Replace("\"", "\"\"");

            if (valor.Contains(";") || valor.Contains(",") || valor.Contains("\n") || valor.Contains("\""))
            {
                valor = "\"" + valor + "\"";
            }
            return valor;
        }
        private void txtDiasRestantes_TextChanged(object sender, EventArgs e)
        {

        }

        private void dtpFecha_ValueChanged(object sender, EventArgs e)
        {
            CalcularTiempoRestante();
        }

        private void dtpHora_ValueChanged(object sender, EventArgs e)
        {
            CalcularTiempoRestante();
        }

        private void grpAcciones_Enter(object sender, EventArgs e)
        {

        }

        private void grpDatosCita_Enter(object sender, EventArgs e)
        {

        }

        private void btnExportarCsv_Click(object sender, EventArgs e)
        {
            int filasConDatos = dgvCitas.Rows
                .Cast<DataGridViewRow>()
                .Count(r => !r.IsNewRow);

            if (filasConDatos == 0)
            {
                MessageBox.Show("No hay datos para exportar.", "Información",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "Archivo CSV (*.csv)|*.csv";
                sfd.FileName = "Citas.csv";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        StringBuilder sb = new StringBuilder();

                        var columnasVisibles = dgvCitas.Columns
                            .Cast<DataGridViewColumn>()
                            .Where(c => c.Visible)
                            .ToList();

                        sb.AppendLine(string.Join(";", columnasVisibles
                            .Select(c => EscaparCsv(c.HeaderText))));

                        foreach (DataGridViewRow fila in dgvCitas.Rows)
                        {
                            if (fila.IsNewRow)
                                continue;

                            var valores = new List<string>();

                            foreach (var col in columnasVisibles)
                            {
                                var celda = fila.Cells[col.Index];
                                var valor = celda.Value != null ? celda.Value.ToString() : "";
                                valores.Add(EscaparCsv(valor));
                            }

                            sb.AppendLine(string.Join(";", valores));
                        }

                        File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);

                        MessageBox.Show("Citas exportadas correctamente.", "Información",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al exportar: " + ex.Message, "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}


      
            