﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace TRABAJO_FINAL_PRO2_DIONIS_OZUNA
{
    public partial class FrmTerapeutas : Form
    {
        private string cadena = "Data Source=DIONISOZUNA;Initial Catalog=spa;Integrated Security=True;TrustServerCertificate=True";

        private void CargarTerapeutas()
        {
            string sql = "SELECT TerapeutaID, Nombre, Especialidad FROM Terapeuta";

            using (SqlConnection cn = new SqlConnection(cadena))
            {
                SqlDataAdapter da = new SqlDataAdapter(sql, cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvTerapeutas.DataSource = dt;
            }
        }

        private void LimpiarCampos()
        {
            txtTerapeutaID.Clear();
            txtNombre.Clear();
            txtEspecialidad.Clear();
            txtNombre.Focus();
        }
        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtEspecialidad.Text))
            {
                MessageBox.Show("Nombre y Especialidad son obligatorios.",
                    "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
        public FrmTerapeutas()
        {
            InitializeComponent();
        }
        private void btnExportarCsv_Click(object sender, EventArgs e)
        {
            if (dgvTerapeutas.Rows.Count == 0)
            {
                MessageBox.Show("No hay datos para exportar.", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "Archivo CSV (*.csv)|*.csv";
                sfd.FileName = "Terapeutas.csv";

                if (sfd.ShowDialog() != DialogResult.OK)
                    return;

                StringBuilder sb = new StringBuilder();

                sb.AppendLine("TerapeutaID;Nombre;Especialidad");

                foreach (DataGridViewRow row in dgvTerapeutas.Rows)
                {
                    if (row.IsNewRow) continue;

                    string id = Convert.ToString(row.Cells["TerapeutaID"].Value);
                    string nombre = Convert.ToString(row.Cells["Nombre"].Value);
                    string especialidad = Convert.ToString(row.Cells["Especialidad"].Value);

                    sb.AppendLine($"{id};{nombre};{especialidad}");
                }

                File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);

                MessageBox.Show("Datos exportados correctamente.", "Información",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void dgvTerapeutas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
        private void FrmTerapeutas_Load(object sender, EventArgs e)
        {
            txtTerapeutaID.ReadOnly = true;
            CargarTerapeutas();
        }
        private void btnMostrar_Click(object sender, EventArgs e)
        {
            CargarTerapeutas();
        }
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
                return;

            string sql = @"INSERT INTO Terapeuta (Nombre, Especialidad)
                           VALUES (@Nombre, @Especialidad)";

            using (SqlConnection cn = new SqlConnection(cadena))
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text.Trim());
                cmd.Parameters.AddWithValue("@Especialidad", txtEspecialidad.Text.Trim());

                cn.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Terapeuta guardado correctamente.", "Información",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            CargarTerapeutas();
            LimpiarCampos();
        }
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
                return;

            if (!int.TryParse(txtTerapeutaID.Text, out int terapeutaID))
            {
                MessageBox.Show("Debe seleccionar un terapeuta válido.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string sql = @"UPDATE Terapeuta
                           SET Nombre = @Nombre,
                               Especialidad = @Especialidad
                           WHERE TerapeutaID = @TerapeutaID";

            using (SqlConnection cn = new SqlConnection(cadena))
            using (SqlCommand cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@TerapeutaID", terapeutaID);
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text.Trim());
                cmd.Parameters.AddWithValue("@Especialidad", txtEspecialidad.Text.Trim());

                cn.Open();
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Terapeuta actualizado correctamente.", "Información",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            CargarTerapeutas();
        }
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtTerapeutaID.Text, out int terapeutaID))
            {
                MessageBox.Show("Debe seleccionar un terapeuta válido.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult resp = MessageBox.Show(
                "¿Está seguro de eliminar este terapeuta?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (resp != DialogResult.Yes)
                return;

            string sql = @"DELETE FROM Terapeuta WHERE TerapeutaID = @TerapeutaID";

            try
            {
                using (SqlConnection cn = new SqlConnection(cadena))
                using (SqlCommand cmd = new SqlCommand(sql, cn))
                {
                    cmd.Parameters.AddWithValue("@TerapeutaID", terapeutaID);
                    cn.Open();
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Terapeuta eliminado correctamente.", "Información",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                CargarTerapeutas();
                LimpiarCampos();
            }
            catch (SqlException)
            {
                MessageBox.Show("No se puede eliminar el terapeuta porque tiene citas asociadas.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void dgvTerapeutas_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex < 0) return;

            DataGridViewRow fila = dgvTerapeutas.Rows[e.RowIndex];

            txtTerapeutaID.Text = fila.Cells["TerapeutaID"].Value?.ToString();
            txtNombre.Text = fila.Cells["Nombre"].Value?.ToString();
            txtEspecialidad.Text = fila.Cells["Especialidad"].Value?.ToString();
        }
    }
    
}
