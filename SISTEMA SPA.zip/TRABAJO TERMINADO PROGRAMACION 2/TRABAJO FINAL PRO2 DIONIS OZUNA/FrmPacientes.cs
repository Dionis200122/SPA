﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;


namespace TRABAJO_FINAL_PRO2_DIONIS_OZUNA
{
    public partial class FrmPacientes : Form
    {
        public FrmPacientes()
        {
            InitializeComponent();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            string sql = "SELECT PacienteID, Nombre, Telefono, Email FROM Paciente";

            using (SqlConnection cn = new SqlConnection(
                "Data Source=DIONISOZUNA;Initial Catalog=spa;Integrated Security=True;TrustServerCertificate=True"))
            {
                SqlDataAdapter da = new SqlDataAdapter(sql, cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvPacientes.DataSource = dt;
            }
        }
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Debe completar todos los campos.", "Aviso",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string sql = @"INSERT INTO Paciente (Nombre, Telefono, Email) 
                   VALUES (@Nombre, @Telefono, @Email)";

            using (SqlConnection cn = new SqlConnection(
                "Data Source=DIONISOZUNA;Initial Catalog=spa;Integrated Security=True;TrustServerCertificate=True"))
            {
                SqlCommand cmd = new SqlCommand(sql, cn);

                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text.Trim());
                cmd.Parameters.AddWithValue("@Telefono", txtTelefono.Text.Trim());
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());

                cn.Open();
                int filas = cmd.ExecuteNonQuery();

                if (filas > 0)
                {
                    MessageBox.Show("Paciente guardado correctamente.", "Éxito",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                    string sqlSelect = "SELECT PacienteID, Nombre, Telefono, Email FROM Paciente";
                    SqlDataAdapter da = new SqlDataAdapter(sqlSelect, cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvPacientes.DataSource = dt;

                    txtPacienteID.Clear();
                    txtNombre.Clear();
                    txtTelefono.Clear();
                    txtEmail.Clear();
                }
                else
                {
                    MessageBox.Show("No se pudo guardar el paciente.", "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPacienteID.Text) ||
                string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Todos los campos son obligatorios.", "Aviso",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtPacienteID.Text, out int pacienteID))
            {
                MessageBox.Show("El ID del paciente debe ser un número válido.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string sql = @"UPDATE Paciente
                   SET Nombre = @Nombre,
                       Telefono = @Telefono,
                       Email = @Email
                   WHERE PacienteID = @PacienteID";

            using (SqlConnection cn = new SqlConnection(
                "Data Source=DIONISOZUNA;Initial Catalog=spa;Integrated Security=True;TrustServerCertificate=True"))
            {
                SqlCommand cmd = new SqlCommand(sql, cn);

                cmd.Parameters.AddWithValue("@PacienteID", pacienteID);
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text.Trim());
                cmd.Parameters.AddWithValue("@Telefono", txtTelefono.Text.Trim());
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());

                cn.Open();
                int filas = cmd.ExecuteNonQuery();

                if (filas > 0)
                {
                    MessageBox.Show("Paciente actualizado correctamente.", "Éxito",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                    string sqlSelect = "SELECT PacienteID, Nombre, Telefono, Email FROM Paciente";
                    SqlDataAdapter da = new SqlDataAdapter(sqlSelect, cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvPacientes.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No se encontró un paciente con ese ID.", "Advertencia",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPacienteID.Text))
            {
                MessageBox.Show("Debe ingresar el ID del paciente a eliminar.", "Aviso",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtPacienteID.Text, out int pacienteID))
            {
                MessageBox.Show("El ID del paciente debe ser un número válido.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult resp = MessageBox.Show(
                "¿Está seguro de eliminar este paciente?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (resp != DialogResult.Yes)
                return;

            string sql = "DELETE FROM Paciente WHERE PacienteID = @PacienteID";

            using (SqlConnection cn = new SqlConnection(
                "Data Source=DIONISOZUNA;Initial Catalog=spa;Integrated Security=True;TrustServerCertificate=True"))
            {
                SqlCommand cmd = new SqlCommand(sql, cn);
                cmd.Parameters.AddWithValue("@PacienteID", pacienteID);

                cn.Open();
                int filas = cmd.ExecuteNonQuery();

                if (filas > 0)
                {
                    MessageBox.Show("Paciente eliminado correctamente.", "Éxito",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                    string sqlSelect = "SELECT PacienteID, Nombre, Telefono, Email FROM Paciente";
                    SqlDataAdapter da = new SqlDataAdapter(sqlSelect, cn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvPacientes.DataSource = dt;

                    txtPacienteID.Clear();
                    txtNombre.Clear();
                    txtTelefono.Clear();
                    txtEmail.Clear();
                }
                else
                {
                    MessageBox.Show("No se encontró un paciente con ese ID.", "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dgvPacientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow fila = dgvPacientes.Rows[e.RowIndex];

            txtPacienteID.Text = fila.Cells["PacienteID"].Value?.ToString();
            txtNombre.Text = fila.Cells["Nombre"].Value?.ToString();
            txtTelefono.Text = fila.Cells["Telefono"].Value?.ToString();
            txtEmail.Text = fila.Cells["Email"].Value?.ToString();
        }

        private void FrmPacientes_Load(object sender, EventArgs e)
        {

        }
        private string EscaparCsv(string valor)
        {
            if (valor == null)
                return "";

            valor = valor.Replace("\"", "\"\"");

            if (valor.Contains(";") || valor.Contains(",") || valor.Contains("\n") || valor.Contains("\""))
            {
                valor = "\"" + valor + "\"";
            }

            return valor;
        }
        private void btnExportarCsv_Click(object sender, EventArgs e)
        {
            int filasConDatos = dgvPacientes.Rows
                .Cast<DataGridViewRow>()
                .Count(r => !r.IsNewRow);

            if (filasConDatos == 0)
            {
                MessageBox.Show("No hay datos para exportar.", "Información",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "Archivo CSV (*.csv)|*.csv";
                sfd.FileName = "Pacientes.csv";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        StringBuilder sb = new StringBuilder();

                        var columnasVisibles = dgvPacientes.Columns
                            .Cast<DataGridViewColumn>()
                            .Where(c => c.Visible)
                            .ToList();

                        sb.AppendLine(string.Join(";", columnasVisibles
                            .Select(c => EscaparCsv(c.HeaderText))));

                        foreach (DataGridViewRow fila in dgvPacientes.Rows)
                        {
                            if (fila.IsNewRow)
                                continue;

                            var valores = new List<string>();

                            foreach (var col in columnasVisibles)
                            {
                                var celda = fila.Cells[col.Index];
                                var valor = celda.Value != null ? celda.Value.ToString() : "";
                                valores.Add(EscaparCsv(valor));
                            }

                            sb.AppendLine(string.Join(";", valores));
                        }

                        File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);

                        MessageBox.Show("Pacientes exportados correctamente.", "Información",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al exportar: " + ex.Message, "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}