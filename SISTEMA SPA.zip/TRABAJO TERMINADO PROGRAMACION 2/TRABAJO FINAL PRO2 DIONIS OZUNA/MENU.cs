﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TRABAJO_FINAL_PRO2_DIONIS_OZUNA
{
    public partial class MENU : Form
    {
        public MENU()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void mostrarToolStripMenuItem_Click(object sender, EventArgs e)
        {

            
        }

        private void pacientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmPacientes f = new FrmPacientes();
            f.ShowDialog();
        }

        private void serviciosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmServicios f = new FrmServicios();
            f.ShowDialog();
        }

        private void citasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCitas f = new FrmCitas();
            f.ShowDialog();
        }

        private void terapeutasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmTerapeutas f = new FrmTerapeutas();
            f.ShowDialog();
        }
    }
    
}
